package com.example.tugasintegrasiactivity

import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tugasintegrasiactivity.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    // Inisialisasi binding
    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup binding
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Daftar pilihan gender
        val genderOptions = arrayOf("Chose Gender","Male", "Female")

        // Membuat adapter untuk spinner
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, genderOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.etGender.adapter = adapter

        // Handle button register click
        binding.btnRegister.setOnClickListener {
            val name = binding.etName.text.toString()
            val email = binding.etEmail.text.toString()
            val phone = binding.etPhone.text.toString()
            val gender = binding.etGender.selectedItem.toString()

            // Cek apakah ada kolom yang kosong
            if (name.isEmpty()) {
                binding.etName.error = "Please input your Full Name"
                return@setOnClickListener
            }
            if (email.isEmpty()) {
                binding.etEmail.error = "Please input your Email"
                return@setOnClickListener
            }
            if (phone.isEmpty()) {
                binding.etPhone.error = "Please input your Phone Number"
                return@setOnClickListener
            }
            if (binding.etGender.selectedItemPosition == 0) { // pastikan gender bukan "Pilih Gender"
                Toast.makeText(this, "Chose Gender!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Passing data ke Login Activity
            val intent = Intent(this, LoginActivity::class.java).apply {
                putExtra("EXTRA_NAME", name)
                putExtra("EXTRA_EMAIL", email)
                putExtra("EXTRA_PHONE", phone)
                putExtra("EXTRA_GENDER", gender)
            }
            startActivity(intent)
        }
    }
}
