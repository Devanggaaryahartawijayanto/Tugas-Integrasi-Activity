package com.example.tugasintegrasiactivity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.tugasintegrasiactivity.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup binding
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        with(binding) {
            btnBackLogin.setOnClickListener {
                val intentToMainActivity =
                    Intent(this@ProfileActivity, LoginActivity::class.java)
                startActivity(intentToMainActivity)
            }
        }


            // Ambil data dari Login Activity
        val name = intent.getStringExtra("EXTRA_NAME")
        val email = intent.getStringExtra("EXTRA_EMAIL")
        val phone = intent.getStringExtra("EXTRA_PHONE")
        val gender = intent.getStringExtra("EXTRA_GENDER")

        // Set data ke TextView
        binding.tvNameProfile.text = "Name: $name"
        binding.tvEmailProfile.text = "Email: $email"
        binding.tvPhoneProfile.text = "Phone Number: $phone"
        binding.tvGenderProfile.text = "Gender: $gender"
    }
}
